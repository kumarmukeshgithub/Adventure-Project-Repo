# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Layer Script

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Accessing Using App

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
            "fs.azure.account.oauth2.client.id":"0d0e6b10-ee71-487b-b3fb-e06948d02f75",
             "fs.azure.account.oauth2.client.secret":"ino8Q~xDiGRwgagtOrnY15LWLel2WufIdhUG5awW",
             "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/9e391f6e-85ce-42ac-801f-4052eeb10ac6/oauth2/token"}

dbutils.fs.mount(
source = "abfss://bronzelayer@adventureprojectstorage.dfs.core.windows.net/",
mount_point = "/mnt/awproject",
extra_configs = configs)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "/mnt/awproject"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read Calander Data

# COMMAND ----------

Calendar_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Calendar/AdventureWorks_Calendar.csv",header=True,inferSchema=True)
display(Calendar_df)

# COMMAND ----------

Customers_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Customers/AdventureWorks_Customers.csv",header=True,inferSchema=True)
display(Customers_df)

# COMMAND ----------

Product_Categories_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Product_Categories/AdventureWorks_Product_Categories.csv",header=True,inferSchema=True)
display(Product_Categories_df)

# COMMAND ----------

Products_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Products/AdventureWorks_Products.csv",header=True,inferSchema=True)
display(Products_df)

# COMMAND ----------

Returns_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Returns/AdventureWorks_Returns.csv",header=True,inferSchema=True)
display(Returns_df)

# COMMAND ----------

Sales_2015_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Sales_2015/AdventureWorks_Sales_2015.csv",header=True,inferSchema=True)
display(Sales_2015_df)

# COMMAND ----------

Sales_2016_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Sales_2016/AdventureWorks_Sales_2016.cvsv",header=True,inferSchema=True)
display(Sales_2016_df)

# COMMAND ----------

Sales_2017_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Sales_2017/AdventureWorks_Sales_2017.csv",header=True,inferSchema=True)
display(Sales_2017_df)

# COMMAND ----------

Territories_df = spark.read.csv("dbfs:/mnt/awproject/AdventureWorks_Territories/AdventureWorks_Territories.csv",header=True,inferSchema=True)
display(Territories_df)

# COMMAND ----------

Subcategories_df = spark.read.csv("dbfs:/mnt/awproject/Product_Subcategories/AdventureWorks_Product_Subcategories.csv",header=True,inferSchema=True)
display(Subcategories_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mounting Of Silver Layer Folder

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
             "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
            "fs.azure.account.oauth2.client.id":"0d0e6b10-ee71-487b-b3fb-e06948d02f75",
             "fs.azure.account.oauth2.client.secret":"ino8Q~xDiGRwgagtOrnY15LWLel2WufIdhUG5awW",
             "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/9e391f6e-85ce-42ac-801f-4052eeb10ac6/oauth2/token"}

dbutils.fs.mount(
source = "abfss://silverlayer@adventureprojectstorage.dfs.core.windows.net/",
mount_point = "/mnt/awprojectsilver",
extra_configs = configs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformations of Data

# COMMAND ----------


df_cal = Calendar_df.withColumn('Month',month(col('Date')))\
            .withColumn('Year',year(col('Date')))
     

# COMMAND ----------


df_cal.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Calendar")

# COMMAND ----------

cust_df = Customers_df.withColumn("fullName",concat(col("Prefix"),lit(' '),col('FirstName'),col('LastName')))

# COMMAND ----------

cust_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Customers")

# COMMAND ----------

 prod_df=Products_df.withColumn("ProductSKU",split(col("ProductSKU"),'-')[0])\
                    .withColumn("ProductName",split(col("ProductName"),' ')[0])

# COMMAND ----------

cust_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Products")

# COMMAND ----------

Returns_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Returns")

# COMMAND ----------

Territories_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Territories")

# COMMAND ----------

Sales_2017_df.printSchema()

# COMMAND ----------

Sales_df = Sales_2017_df.withColumn("StockDate",to_timestamp('StockDate'))
Sales_df = Sales_df.withColumn("OrderNumber",regexp_replace(col('OrderNumber'),'S','T'))
Sales_df = Sales_df.withColumn("Smultiply",col('OrderLineItem')*col('OrderQuantity'))


# COMMAND ----------

display(Sales_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sales Analysis

# COMMAND ----------

Sales_df.groupBy('OrderDate').agg(count('OrderNumber').alias('total_order')).display()

# COMMAND ----------

Sales_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Sales")

# COMMAND ----------

Subcategories_df.write.mode("overwrite").option("header", "true").parquet("/mnt/awprojectsilver/AdventureWorks_Subcategories")

# COMMAND ----------

